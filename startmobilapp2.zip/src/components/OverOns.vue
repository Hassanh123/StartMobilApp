<template>
  <div class="container mx-auto px-4 sm:px-6 md:px-8 lg:px-12 py-12 max-w-screen-xl">
    <div class="mx-auto max-w-4xl text-center">
      <h1 class="text-3xl md:text-5xl font-bold text-blue-800 mb-8">Over Ons</h1>
      <p class="mb-6 text-gray-700 leading-relaxed text-lg">
        Welkom bij StartMobil, jouw betrouwbare partner in autoverhuur. Sinds onze oprichting streven we ernaar om mobiliteit voor iedereen toegankelijk, betaalbaar en eenvoudig te maken. Of je nu snel een auto nodig hebt voor een spontane roadtrip of een praktische wagen voor je dagelijkse ritten – bij ons ben je aan het juiste adres.
      </p>
      <p class="mb-6 text-gray-700 leading-relaxed text-lg">
        Ons team bestaat uit gepassioneerde professionals die er alles aan doen om jou een perfecte rijervaring te bieden. Wij staan bekend om onze klantvriendelijkheid en flexibiliteit, waardoor je zorgeloos en met plezier de weg op gaat. Van compacte stadsauto’s tot ruime gezinswagens – onze vloot is veelzijdig en altijd in topconditie.
      </p>
      <p class="mb-6 text-gray-700 leading-relaxed text-lg">
        Wij geloven in transparante voorwaarden, uitstekende service en een persoonlijke aanpak. Geen kleine lettertjes, geen verrassingen – alleen duidelijkheid en vertrouwen. Onze klanten waarderen vooral onze snelle service, eerlijke prijzen en het gemak van online reserveren.
      </p>
      <p class="mb-6 text-gray-700 leading-relaxed text-lg">
        StartMobil is meer dan alleen een autoverhuurbedrijf – wij zijn jouw partner in mobiliteit. Of je nu particulier huurt of zakelijk rijdt, wij denken met je mee en bieden oplossingen op maat.
      </p>
      <p class="text-gray-700 leading-relaxed text-lg">
        Heb je vragen of wil je meer weten? Neem gerust contact met ons op. Wij helpen je graag verder en zorgen dat je snel en veilig de weg op kunt!
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'OverOnsPage',
}
</script>
